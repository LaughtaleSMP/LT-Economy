// auction/storage.js

import { world } from "@minecraft/server";
import { CFG } from "../config.js";
import { getByteLength } from "../../dp_manager.js";
import { getTierFeePct } from "../../market/tier.js";

// [§7.4] Injected at runtime by sync.js — auction works even without sync module.
let _pushToSupabase = null;
export function _injectAuctionSync(fn) { _pushToSupabase = fn; }

// ═══════════════════════════════════════════════════════════
// DYNAMIC PROPERTY WRAPPER
// ═══════════════════════════════════════════════════════════
const dp = {
  get: (k, def) => {
    try { return JSON.parse(world.getDynamicProperty(k) ?? "null") ?? def; }
    catch { return def; }
  },
  set: (k, v) => {
    try {
      const str = JSON.stringify(v);
      const byteLen = getByteLength(str);
      if (byteLen > 30_000)
        console.warn(`[Auction] dp.set WARNING: "${k}" ${byteLen} bytes (limit 32KB)`);
      world.setDynamicProperty(k, str);
    } catch (e) { console.error("[Auction] dp.set gagal:", k, e); }
  },
  del: (k) => { try { world.setDynamicProperty(k, undefined); } catch {} },
};

export { dp };

// ═══════════════════════════════════════════════════════════
// SETTINGS (cached)
// ═══════════════════════════════════════════════════════════
let _settingsCache = null;

export function getSettings() {
  if (!_settingsCache) _settingsCache = dp.get(CFG.K_SETTINGS, { feePct: CFG.LISTING_FEE_PCT });
  return _settingsCache;
}
export function saveSettings(s) {
  _settingsCache = s;
  dp.set(CFG.K_SETTINGS, s);
}
export const getFee  = () => Math.max(0, getSettings().feePct + _getPolicyAdj());
let _polCache = null, _polTs = 0;
function _getPolicyAdj() {
  const now = Date.now();
  if (_polCache !== null && now - _polTs < 300000) return _polCache;
  try {
    const raw = world.getDynamicProperty("eco:policy");
    if (raw) { _polCache = JSON.parse(raw).adj || 0; _polTs = now; return _polCache; }
  } catch {}
  _polCache = 0; _polTs = now;
  return 0;
}
export function calcFee(n, playerOrName) {
  let base;
  if (playerOrName) {
    base = Math.max(0, getTierFeePct(playerOrName, getSettings().feePct) + _getPolicyAdj());
  } else {
    base = getFee();
  }
  let extra = 0;
  for (const b of CFG.FEE_BRACKETS) {
    if (n <= b.max) { extra = b.extra; break; }
  }
  return Math.ceil(n * (base + extra) / 100);
}

export function getPlayerFee(playerOrName) {
  return Math.max(0, getTierFeePct(playerOrName, getSettings().feePct) + _getPolicyAdj());
}

// ═══════════════════════════════════════════════════════════
// LISTINGS CRUD (cached — hindari JSON.parse berulang)
// ═══════════════════════════════════════════════════════════
let _listCache = null;  // in-memory cache, null = belum loaded

export const genId = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 5);

/**
 * Ambil semua listings dari cache (atau load dari DP jika belum).
 * Mengembalikan referensi langsung — jangan mutasi tanpa saveListings()!
 */
export function getListings() {
  if (_listCache === null) {
    _listCache = dp.get(CFG.K_LISTINGS, []);
  }
  return _listCache;
}

/**
 * Simpan listings ke DP dan update cache.
 * Jika ukuran data mendekati batas DP, auto-prune entri lama.
 */
export function saveListings(listings) {
  _listCache = listings;
  const str = JSON.stringify(listings);
  const byteLen = getByteLength(str);

  // Size guard: byte-accurate — jika mendekati batas, buang entri non-active terlama
  if (byteLen > CFG.DP_MAX_BYTES) {
    console.warn(`[Auction] saveListings: ${byteLen} bytes > ${CFG.DP_MAX_BYTES} limit! Auto-pruning...`);
    // [PERF] Hapus sold/expired paling lama, estimasi ~700B per entri
    // Hindari JSON.stringify berulang di dalam loop (mahal)
    const sorted = listings
      .filter(l => l.status !== "active")
      .sort((a, b) => (a.expiresAt ?? a.createdAt) - (b.expiresAt ?? b.createdAt));
    let estBytes = byteLen;
    while (sorted.length > 0 && estBytes > CFG.DP_MAX_BYTES) {
      const oldest = sorted.shift();
      const idx = listings.indexOf(oldest);
      if (idx >= 0) {
        // Estimasi bytes yang dihemat (hindari stringify ulang)
        estBytes -= getByteLength(JSON.stringify(oldest)) + 1; // +1 untuk koma
        listings.splice(idx, 1);
      }
    }
    _listCache = listings;
  }

  dp.set(CFG.K_LISTINGS, listings);
}

export function getActiveListings() {
  const now = Date.now();
  return getListings().filter(l => l.status === "active" && l.expiresAt > now);
}

export function getPlayerActiveCount(playerId) {
  return getActiveListings().filter(l => l.sellerId === playerId).length;
}

export function getListing(id) {
  return getListings().find(l => l.id === id) ?? null;
}

export function addListing(listing) {
  const all = getListings();
  all.push(listing);
  saveListings(all);
}

export function removeListing(id) {
  saveListings(getListings().filter(l => l.id !== id));
}

export function updateListing(id, updater) {
  const all = getListings();
  const idx = all.findIndex(l => l.id === id);
  if (idx < 0) return false;
  updater(all[idx]);
  saveListings(all);
  return true;
}

// ═══════════════════════════════════════════════════════════
// PRUNE EXPIRED (optimized — skip jika tidak ada yg expired)
// ═══════════════════════════════════════════════════════════
export function pruneExpired() {
  const now = Date.now();
  const all = getListings();

  // Quick check: ada yang perlu di-prune?
  const needsPrune = all.some(l =>
    (l.status === "active" && l.expiresAt <= now) ||
    (l.status !== "active" && (now - (l.expiresAt ?? l.createdAt)) > CFG.OLD_RETAIN_MS)
  );
  if (!needsPrune) return { expired: [], settled: [] };

  const expired = [];
  const settled = [];
  const kept    = [];

  for (const l of all) {
    if (l.status === "active" && l.expiresAt <= now) {
      // Auction with winning bid → auto-settle as sold
      if (l.mode === "auction" && l.bidderId && l.currentBid > 0) {
        l.status = "sold";
        l.buyerId = l.bidderId;
        l.buyerName = l.bidderName;
        settled.push(l);
      } else {
        l.status = "expired";
        expired.push(l);
      }
    }
    // Buang entri lama setelah OLD_RETAIN_MS
    if (l.status !== "active" && (now - (l.expiresAt ?? l.createdAt)) > CFG.OLD_RETAIN_MS) {
      continue;
    }
    kept.push(l);
  }

  if (expired.length > 0 || settled.length > 0 || kept.length !== all.length) {
    saveListings(kept);
  }
  return { expired, settled };
}

// ═══════════════════════════════════════════════════════════
// HISTORY — global auction log
// ═══════════════════════════════════════════════════════════
export function getHistory() {
  return dp.get(CFG.K_HIST, []);
}

export function pushHistory(entry) {
  const hist = getHistory();
  const now = Date.now();

  // [FIX] Guard against duplicate entries from behavior pack restarts.
  // If an identical entry (same item+seller+type) was pushed within
  // the last 60s, skip — this is a replay, not a new event.
  const DUP_WINDOW_MS = 60_000;
  const isDup = hist.some(h =>
    h.type === entry.type &&
    h.item === entry.item &&
    h.seller === entry.seller &&
    (h.buyer || "") === (entry.buyer || "") &&
    h.ts && (now - h.ts) < DUP_WINDOW_MS
  );
  if (isDup) return;

  hist.unshift({ ...entry, ts: now });
  dp.set(CFG.K_HIST, hist.slice(0, CFG.MAX_HIST));

  // Push to permanent Supabase storage (fire-and-forget buffer)
  if (_pushToSupabase) _pushToSupabase(entry);
}

// [FIX] One-time cleanup: remove existing duplicate entries from history.
// Runs on behavior pack load. No-op if no duplicates found (zero DP writes).
(function _cleanupDupHistory() {
  try {
    const hist = dp.get(CFG.K_HIST, []);
    if (hist.length < 2) return;
    const seen = new Set();
    const cleaned = hist.filter(h => {
      const k = (h.type || '') + '|' + (h.item || '') + '|' + (h.seller || '') + '|' + (h.buyer || '') + '|' + (h.ts || 0) + '|' + (h.price || 0) + '|' + (h.qty || 1);
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    if (cleaned.length < hist.length) {
      dp.set(CFG.K_HIST, cleaned);
      console.log(`[Auction] Cleaned ${hist.length - cleaned.length} duplicate history entries.`);
    }
  } catch (e) { console.warn("[Auction] History cleanup:", e); }
})();

// Cached 60s — hindari re-parse DP berulang. Read-only, no side-effects.
let _recCache = null, _recCacheTs = 0;
const _REC_TTL = 60_000;
const _REC_SOLD = { sold: 1, offer_accepted: 1, auction_won: 1 };

export function getPriceRecommendation(itemId, qty) {
  if (!itemId || typeof itemId !== "string") return null;
  const safeQty = Number.isFinite(qty) && qty > 0 ? Math.floor(qty) : 1;

  try {
    const now = Date.now();
    if (!_recCache || now - _recCacheTs > _REC_TTL) {
      _recCache = getHistory();
      _recCacheTs = now;
    }

    let totalPrice = 0, totalQty = 0, minPpu = Infinity, maxPpu = 0, txCount = 0;

    for (const h of _recCache) {
      if (!_REC_SOLD[h.type]) continue;
      if (h.itemId !== itemId) continue;
      const p = Number(h.price) || 0;
      if (p <= 0) continue;
      const q = Number(h.qty) || 1;
      const ppu = p / q;
      totalPrice += p;
      totalQty += q;
      if (ppu < minPpu) minPpu = ppu;
      if (ppu > maxPpu) maxPpu = ppu;
      txCount++;
    }

    if (txCount === 0) return null;

    const perUnit = Math.round(totalPrice / totalQty);
    return {
      // Cap ke MAX_BUYOUT agar default value tidak melampaui batas form
      avg: Math.min(perUnit * safeQty, CFG.MAX_BUYOUT),
      min: Math.min(Math.round(minPpu * safeQty), CFG.MAX_BUYOUT),
      max: Math.min(Math.round(maxPpu * safeQty), CFG.MAX_BUYOUT),
      perUnit,
      txCount,
    };
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════════════════
// PENDING NOTIFICATIONS (offline)
// ═══════════════════════════════════════════════════════════
export function pushNotif(playerId, msg) {
  const list = dp.get(CFG.K_NOTIF + playerId, []);
  list.push(msg);
  dp.set(CFG.K_NOTIF + playerId, list.slice(0, 15));
}

export function flushNotifs(player) {
  const list = dp.get(CFG.K_NOTIF + player.id, []);
  if (!list.length) return;
  dp.del(CFG.K_NOTIF + player.id);
  for (const msg of list) player.sendMessage(msg);
}

// ═══════════════════════════════════════════════════════════
// PENDING ITEMS (expired / cancelled listing returns)
// ═══════════════════════════════════════════════════════════
export function getPendingItems(playerId) {
  return dp.get(CFG.K_PEND_ITEMS + playerId, []);
}

export function addPendingItem(playerId, itemData) {
  const list = getPendingItems(playerId);
  list.push(itemData);
  // Batas max 20 pending items per player (mencegah DP overflow)
  if (list.length > 20) {
    console.warn(`[Auction] addPendingItem: player ${playerId} punya ${list.length} pending items, trim ke 20.`);
    list.splice(0, list.length - 20); // hapus terlama
  }
  dp.set(CFG.K_PEND_ITEMS + playerId, list);
}

export function clearPendingItems(playerId) {
  dp.del(CFG.K_PEND_ITEMS + playerId);
}

export function savePendingItems(playerId, list) {
  if (!list.length) dp.del(CFG.K_PEND_ITEMS + playerId);
  else dp.set(CFG.K_PEND_ITEMS + playerId, list);
}

// ═══════════════════════════════════════════════════════════
// PENDING COIN (offline seller/bidder refund)
// ═══════════════════════════════════════════════════════════
export function addPendingCoin(playerId, amount) {
  // [§2/§3] Validate amount — never accept negative/NaN that could corrupt pending.
  const n = Math.floor(Number(amount));
  if (!Number.isFinite(n) || n <= 0) return;
  const key = CFG.K_PEND_COIN + playerId;
  const existing = dp.get(key, 0);
  // Cap at int32 to prevent overflow.
  const next = Math.min(2_147_483_647, existing + n);
  dp.set(key, next);
}

export function claimPendingCoin(player, addCoinFn) {
  const key = CFG.K_PEND_COIN + player.id;
  const amount = dp.get(key, 0);
  if (amount <= 0) return 0;
  // [§2] Only delete pending if scoreboard write succeeded.
  // Treat undefined return (legacy) as success for backward compat.
  const result = addCoinFn(player, amount);
  if (result === false) {
    console.warn(`[Auction] claimPendingCoin failed, kept for retry: ${player.name} ${amount}`);
    return 0;
  }
  dp.del(key);
  return amount;
}

// ═══════════════════════════════════════════════════════════
// TRANSACTION JOURNAL (Write-Ahead Log)
// Proteksi crash: tulis intent SEBELUM operasi,
// hapus SETELAH selesai. Recovery saat startup.
// ═══════════════════════════════════════════════════════════

/**
 * Tulis transaksi sebelum operasi berbahaya.
 * @param {string} playerId
 * @param {object} tx - { type: "sell"|"buy", ...data }
 */
export function writeTx(playerId, tx) {
  dp.set(CFG.K_TX + playerId, { ...tx, ts: Date.now() });
}

/**
 * Hapus transaksi setelah operasi berhasil.
 */
export function clearTx(playerId) {
  dp.del(CFG.K_TX + playerId);
}

/**
 * Cek apakah ada transaksi incomplete untuk player.
 */
export function getTx(playerId) {
  return dp.get(CFG.K_TX + playerId, null);
}

/**
 * Recovery: dipanggil saat player login.
 * Mengembalikan item/koin yang tertahan akibat crash.
 * @returns {string[]} pesan recovery untuk player
 */
export function recoverTx(playerId) {
  const tx = getTx(playerId);
  if (!tx) return [];

  const messages = [];

  try {
    if (tx.type === "sell") {
      const listing = getListings().find(l => l.id === tx.listingId);
      if (!listing) {
        if (tx.itemData) {
          addPendingItem(playerId, tx.itemData);
          messages.push("§8[§eAuction Recovery§8]§e Item dari listing gagal dikembalikan ke pending.");
        }
      }
    }

    if (tx.type === "buy") {
      const listing = getListings().find(l => l.id === tx.listingId);
      if (listing && listing.status === "active") {
        addPendingCoin(playerId, tx.price);
        messages.push(`§8[§eAuction Recovery§8]§e Pembelian gagal, §f${tx.price} Koin §edikembalikan.`);
      }
    }

    if (tx.type === "bid") {
      const listing = getListings().find(l => l.id === tx.listingId);
      // Jika listing masih aktif tapi bidder bukan kita → bid gagal, refund
      if (!listing || (listing.bidderId !== playerId)) {
        if (tx.amount > 0) {
          addPendingCoin(playerId, tx.amount);
          messages.push(`§8[§eAuction Recovery§8]§e Bid gagal, §f${tx.amount} Koin §edikembalikan.`);
        }
      }
    }
  } catch (e) {
    console.error("[Auction] recoverTx error:", e);
    messages.push("§8[§cAuction Recovery§8]§c Terjadi error saat recovery. Hubungi admin.");
  }

  clearTx(playerId);
  return messages;
}
